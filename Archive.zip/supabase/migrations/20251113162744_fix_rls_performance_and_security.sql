/*
  # Fix RLS Performance and Security Issues

  1. Performance Improvements
    - Update all RLS policies to use `(select auth.uid())` instead of `auth.uid()`
    - This prevents re-evaluation of auth.uid() for each row, improving query performance at scale
    - Affects policies on: sessions, settings, subs tables

  2. Index Cleanup
    - Remove unused index `sessions_user_id_created_at_idx`
    - This index is not being utilized by queries

  3. Security Improvements
    - Fix `handle_new_user` function to use immutable search_path
    - Prevents potential search_path manipulation attacks

  ## Changes by Table

  ### sessions table
  - Drop and recreate: "Users can view own sessions" policy
  - Drop and recreate: "Users can insert own sessions" policy
  - Drop and recreate: "Users can update own sessions" policy

  ### settings table
  - Drop and recreate: "Users can view own settings" policy
  - Drop and recreate: "Users can insert own settings" policy
  - Drop and recreate: "Users can update own settings" policy

  ### subs table
  - Drop and recreate: "Users can view own subscription" policy
  - Drop and recreate: "Users can insert own subscription" policy
  - Drop and recreate: "Users can update own subscription" policy
*/

-- Fix sessions table RLS policies
DROP POLICY IF EXISTS "Users can view own sessions" ON sessions;
CREATE POLICY "Users can view own sessions"
  ON sessions FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own sessions" ON sessions;
CREATE POLICY "Users can insert own sessions"
  ON sessions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own sessions" ON sessions;
CREATE POLICY "Users can update own sessions"
  ON sessions FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Fix settings table RLS policies
DROP POLICY IF EXISTS "Users can view own settings" ON settings;
CREATE POLICY "Users can view own settings"
  ON settings FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own settings" ON settings;
CREATE POLICY "Users can insert own settings"
  ON settings FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own settings" ON settings;
CREATE POLICY "Users can update own settings"
  ON settings FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Fix subs table RLS policies
DROP POLICY IF EXISTS "Users can view own subscription" ON subs;
CREATE POLICY "Users can view own subscription"
  ON subs FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own subscription" ON subs;
CREATE POLICY "Users can insert own subscription"
  ON subs FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own subscription" ON subs;
CREATE POLICY "Users can update own subscription"
  ON subs FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Remove unused index
DROP INDEX IF EXISTS sessions_user_id_created_at_idx;

-- Fix handle_new_user function with immutable search_path
DROP FUNCTION IF EXISTS handle_new_user() CASCADE;

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
BEGIN
  INSERT INTO public.settings (user_id)
  VALUES (NEW.id);
  
  INSERT INTO public.subs (user_id, tier, status)
  VALUES (NEW.id, 'free', 'active');
  
  RETURN NEW;
END;
$$;

-- Recreate trigger if needed
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();
