'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Wind } from 'lucide-react';

type BreathingExerciseProps = {
  duration?: number;
  onComplete?: () => void;
};

export function BreathingExercise({ duration = 60, onComplete }: BreathingExerciseProps) {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [timeLeft, setTimeLeft] = useState(duration);
  const [cycleProgress, setCycleProgress] = useState(0);

  const phaseDurations = {
    inhale: 4,
    hold: 7,
    exhale: 8,
  };

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsActive(false);
          onComplete?.();
          return 0;
        }
        return prev - 1;
      });

      setCycleProgress((prev) => {
        const totalCycle = phaseDurations.inhale + phaseDurations.hold + phaseDurations.exhale;
        const next = (prev + 1) % totalCycle;

        if (next < phaseDurations.inhale) {
          setPhase('inhale');
        } else if (next < phaseDurations.inhale + phaseDurations.hold) {
          setPhase('hold');
        } else {
          setPhase('exhale');
        }

        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, onComplete]);

  const handleStart = () => {
    setIsActive(true);
    setTimeLeft(duration);
    setCycleProgress(0);
    setPhase('inhale');
  };

  const handleStop = () => {
    setIsActive(false);
  };

  const getPhaseText = () => {
    switch (phase) {
      case 'inhale':
        return 'Breathe In';
      case 'hold':
        return 'Hold';
      case 'exhale':
        return 'Breathe Out';
    }
  };

  const getPhaseColor = () => {
    switch (phase) {
      case 'inhale':
        return 'bg-blue-500';
      case 'hold':
        return 'bg-yellow-500';
      case 'exhale':
        return 'bg-green-500';
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col items-center space-y-6">
          <div className="flex items-center space-x-2">
            <Wind className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold">4-7-8 Breathing</h3>
          </div>

          <div className="relative w-48 h-48 flex items-center justify-center">
            <div
              className={`absolute inset-0 rounded-full transition-all duration-1000 ${getPhaseColor()} opacity-20 ${
                isActive && phase === 'inhale' ? 'scale-100' : phase === 'exhale' ? 'scale-75' : 'scale-90'
              }`}
            />
            <div className="relative z-10 text-center">
              {isActive ? (
                <>
                  <div className="text-4xl font-bold mb-2">{getPhaseText()}</div>
                  <div className="text-sm text-gray-600">{timeLeft}s remaining</div>
                </>
              ) : (
                <div className="text-center">
                  <div className="text-2xl font-bold mb-2">Ready</div>
                  <div className="text-sm text-gray-600">Press start</div>
                </div>
              )}
            </div>
          </div>

          <div className="w-full max-w-xs space-y-2">
            <div className="text-sm text-gray-600 text-center">
              {isActive ? (
                `${getPhaseText()} - Follow the rhythm`
              ) : (
                'Inhale 4s → Hold 7s → Exhale 8s'
              )}
            </div>
          </div>

          {!isActive ? (
            <Button onClick={handleStart} className="w-full max-w-xs">
              Start Breathing Exercise
            </Button>
          ) : (
            <Button onClick={handleStop} variant="outline" className="w-full max-w-xs">
              Stop
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
