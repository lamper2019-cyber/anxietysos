import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Session = {
  id: string;
  user_id: string;
  anxiety_level: number;
  triggers?: string;
  calm_plan?: string;
  breathing_exercise?: string;
  notes?: string;
  created_at: string;
};

export type Settings = {
  id: string;
  user_id: string;
  theme: string;
  notifications_enabled: boolean;
  default_breathing_duration: number;
  created_at: string;
  updated_at: string;
};

export type Subscription = {
  id: string;
  user_id: string;
  tier: string;
  status: string;
  created_at: string;
  updated_at: string;
};
