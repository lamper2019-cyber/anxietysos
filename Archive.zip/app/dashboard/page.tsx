'use client';

import { useState, useEffect } from 'react';
import { supabase, type Session } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { BreathingExercise } from '@/components/breathing-exercise';
import { Heart, History, Settings, LogOut, Sparkles, Activity } from 'lucide-react';
import Link from 'next/link';

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [anxietyLevel, setAnxietyLevel] = useState(5);
  const [triggers, setTriggers] = useState('');
  const [notes, setNotes] = useState('');
  const [calmPlan, setCalmPlan] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showBreathing, setShowBreathing] = useState(false);
  const [recentSessions, setRecentSessions] = useState<Session[]>([]);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth');
      } else {
        setUser(user);
        loadRecentSessions(user.id);
      }
    };

    checkUser();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (event === 'SIGNED_OUT') {
          router.push('/auth');
        }
      }
    );

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [router]);

  const loadRecentSessions = async (userId: string) => {
    const { data, error } = await supabase
      .from('sessions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(3);

    if (data) {
      setRecentSessions(data);
    }
  };

  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    setCalmPlan('');

    try {
      const { data: { session } } = await supabase.auth.getSession();

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/generate-calm-plan`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session?.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            anxietyLevel,
            triggers,
          }),
        }
      );

      const data = await response.json();
      const plan = data.plan || 'Unable to generate plan. Please try again.';
      setCalmPlan(plan);
    } catch (error) {
      setCalmPlan('Unable to generate plan. Please check your connection and try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveSession = async () => {
    if (!user) return;

    const { error } = await supabase.from('sessions').insert({
      user_id: user.id,
      anxiety_level: anxietyLevel,
      triggers: triggers || null,
      calm_plan: calmPlan || null,
      notes: notes || null,
    });

    if (!error) {
      setTriggers('');
      setNotes('');
      setCalmPlan('');
      setAnxietyLevel(5);
      loadRecentSessions(user.id);
      alert('Session saved successfully!');
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push('/auth');
  };

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Heart className="w-6 h-6 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">Anxiety SOS</span>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/history">
              <Button variant="ghost" size="sm">
                <History className="w-4 h-4 mr-2" />
                History
              </Button>
            </Link>
            <Link href="/settings">
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
            </Link>
            <Button variant="ghost" size="sm" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back</h1>
          <p className="text-gray-600">How are you feeling today?</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-blue-600" />
                  Track Your Anxiety
                </CardTitle>
                <CardDescription>
                  Record how you're feeling and get personalized support
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Anxiety Level: {anxietyLevel}/10</Label>
                  <Slider
                    value={[anxietyLevel]}
                    onValueChange={(value) => setAnxietyLevel(value[0])}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Calm</span>
                    <span>Mild</span>
                    <span>Moderate</span>
                    <span>Severe</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="triggers">What triggered this feeling?</Label>
                  <Input
                    id="triggers"
                    placeholder="e.g., work deadline, social event..."
                    value={triggers}
                    onChange={(e) => setTriggers(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes (optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Any other thoughts or observations..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3}
                  />
                </div>

                <Button
                  onClick={handleGeneratePlan}
                  disabled={isGenerating}
                  className="w-full"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  {isGenerating ? 'Generating Your Calm Plan...' : 'Generate Personalized Calm Plan'}
                </Button>

                {calmPlan && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900 mb-2">Your Personalized Calm Plan</h4>
                    <p className="text-blue-800 whitespace-pre-wrap">{calmPlan}</p>
                  </div>
                )}

                {calmPlan && (
                  <div className="flex space-x-3">
                    <Button onClick={handleSaveSession} className="flex-1">
                      Save Session
                    </Button>
                    <Button
                      onClick={() => setShowBreathing(!showBreathing)}
                      variant="outline"
                      className="flex-1"
                    >
                      {showBreathing ? 'Hide' : 'Start'} Breathing Exercise
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {showBreathing && (
              <BreathingExercise duration={120} onComplete={() => setShowBreathing(false)} />
            )}
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                {recentSessions.length === 0 ? (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No sessions yet. Start tracking your anxiety above.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {recentSessions.map((session) => (
                      <div
                        key={session.id}
                        className="p-3 bg-gray-50 rounded-lg border border-gray-200"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">
                            Level: {session.anxiety_level}/10
                          </span>
                          <span className="text-xs text-gray-500">
                            {new Date(session.created_at).toLocaleDateString()}
                          </span>
                        </div>
                        {session.triggers && (
                          <p className="text-xs text-gray-600 line-clamp-2">
                            {session.triggers}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                <Link href="/history">
                  <Button variant="outline" className="w-full mt-4" size="sm">
                    View All Sessions
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500 to-green-500 text-white">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Quick Tips</h3>
                <ul className="space-y-2 text-sm">
                  <li>• Take 3 deep breaths</li>
                  <li>• Ground yourself: 5 things you see</li>
                  <li>• Drink a glass of water</li>
                  <li>• Step outside for fresh air</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
