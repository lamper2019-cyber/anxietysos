'use client';

import { useState, useEffect } from 'react';
import { supabase, type Session } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, ArrowLeft, Trash2 } from 'lucide-react';
import Link from 'next/link';

export default function HistoryPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth');
      } else {
        setUser(user);
        loadSessions(user.id);
      }
    };

    checkUser();
  }, [router]);

  const loadSessions = async (userId: string) => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('sessions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (data) {
      setSessions(data);
    }
    setIsLoading(false);
  };

  const handleDelete = async (sessionId: string) => {
    if (!confirm('Are you sure you want to delete this session?')) return;

    const { error } = await supabase
      .from('sessions')
      .delete()
      .eq('id', sessionId);

    if (!error && user) {
      loadSessions(user.id);
    }
  };

  const getAnxietyColor = (level: number) => {
    if (level <= 3) return 'bg-green-100 text-green-800 border-green-200';
    if (level <= 6) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-red-100 text-red-800 border-red-200';
  };

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Heart className="w-6 h-6 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">Anxiety SOS</span>
          </div>
          <Link href="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Session History</h1>
          <p className="text-gray-600">Review your anxiety tracking journey</p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Loading sessions...</p>
          </div>
        ) : sessions.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-gray-500 mb-4">No sessions recorded yet</p>
              <Link href="/dashboard">
                <Button>Start Your First Session</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {sessions.map((session) => (
              <Card key={session.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-medium border ${getAnxietyColor(
                            session.anxiety_level
                          )}`}
                        >
                          Level {session.anxiety_level}/10
                        </span>
                        <span className="text-sm text-gray-500">
                          {new Date(session.created_at).toLocaleString()}
                        </span>
                      </div>
                      {session.triggers && (
                        <div className="mt-2">
                          <p className="text-sm font-medium text-gray-700">Triggers:</p>
                          <p className="text-sm text-gray-600">{session.triggers}</p>
                        </div>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(session.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                {(session.calm_plan || session.notes) && (
                  <CardContent className="pt-0">
                    {session.calm_plan && (
                      <div className="mb-3">
                        <p className="text-sm font-medium text-gray-700 mb-1">Calm Plan:</p>
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-sm text-blue-800 whitespace-pre-wrap">
                            {session.calm_plan}
                          </p>
                        </div>
                      </div>
                    )}
                    {session.notes && (
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Notes:</p>
                        <p className="text-sm text-gray-600">{session.notes}</p>
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}

        {sessions.length > 0 && (
          <div className="mt-8 p-6 bg-white rounded-lg border border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-2">Your Progress</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-blue-600">{sessions.length}</p>
                <p className="text-sm text-gray-600">Total Sessions</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">
                  {(
                    sessions.reduce((sum, s) => sum + s.anxiety_level, 0) / sessions.length
                  ).toFixed(1)}
                </p>
                <p className="text-sm text-gray-600">Avg Anxiety Level</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-600">
                  {sessions.filter((s) => s.calm_plan).length}
                </p>
                <p className="text-sm text-gray-600">Calm Plans Used</p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
